// require('dot')
let express = require('express')
let app = express();
const bodyParser = require('body-parser');
let event = require('events');
const { mongoose } = require('./db.js');
let eventEmitter = new event.EventEmitter();
let http = require('http');
let core = require('cors')
let server = http.Server(app);
let socketIO = require('socket.io');
let io = socketIO(server);
app.use(bodyParser.json());
let userRegistration = require('./controllers/userRegisterController');
// let login = require('./controller')
const userR = require('./controllers/userRegisterController');
const port = process.env.PORT || 3000;
app.use(core());
let userList = [];
app.use('/api', userRegistration);

// app.use('/login', login);  


io.on('connection', (socket) => {
    io.to(socket.id).emit('private', 'Just for you bud');
    // console.log('User Connected', socket.id);
    socket.on('onSetUser', (user, id) => {
        console.log('User Connected', socket.id);
        let valid = true;
        for (let i in userList) {

            if (userList[i] === user) {
                valid = false;
                // username = userList[i].user;
                // console.log(username);
                break;
            }
        }
        setTimeout(() => {
            if (valid) {
                userList.push(user);
                socket.emit('onValidUser', user );
                io.emit('UserAdded', userList);
                console.log(userList);

            } else {
                socket.emit('onInvalidUser');
            }
        }, 100);

        // socketid = socket.id;
        // io.to(socketid).emit('message', user);
        // console.log('User Connected', user , ' ' , socket.id);
    })
    socket.on('client_msg', (msg) => {
        io.emit('on_server_msg', msg);
        console.log(msg);
    });
    socket.on('disconnect', () => {
        // numbers--
        userList.splice(1);
        console.log('user disconnected');
    });
    // socket.broadcast.to(socketid).emit('message', msg);
});




// const userList = [
//     { user: 'mandeep', id: 1 },
//     { user: 'rahul', id: 2 },
//     { user: 'sahil', id: 3 }
// ];
// var sockets = {};
// let username;

// var queue = [];    // list of sockets waiting for peers
// var rooms = {};    // map socket.id => room
// var names = {};    // map socket.id => name
// var allUsers = {}; // map socket.id => socket




// let numbers = 0;
// io.on('connection', (socket) => {
//     // console.log('User Connected', socket.id);
//     // socket.on('user_connected', (username) => {
//     //     people[username] =  socket.id;
//     //     io.emit('user_connected' , username)
//     //     console.log(username);
//     //     });
//     // socket.on('ferret', (name, word, fn) => {
//     //     fn(name + ' says ' + word);
//     //   });


//     numbers++
//     console.log('User Connected', socket.id , ' ',  numbers);
//     // app.get('/' , (res, req) => {
//     //     res.send('User sdgs Connected', socket.id);
//     // })
//     socket.on('onSetUser', user => {
//         let valid = true;
//         for (let i in userList) {

//             if (userList[i].user === user) {
//                 valid = false;
//                 username = userList[i].user;
//                 console.log(username);
//                 break;
//             }
//         }

//         setTimeout(() => {
//             if (!valid) {
//                 userList.push(user);
//                 socket.emit('onValidUser', user);
//                 io.emit('UserAdded', userList);

//             } else {
//                 socket.emit('onInvalidUser');
//             }
//         }, 100);


//         // })  
//         // socket.on('join', (data) => {
//         //     socket.join(data.email); // We are using room of socket io
//         //     io.to('user@example.com').emit('message', {msg: 'hello world.'});
//         //   });
//         // socket.on('new_joinee', (message) => {
//         //     console.log(' msg from client  ' + message)
//         //     socket.join(message.room);
//         //     socket.in(message.room).broadcast.emit('server_new_joinee', {
//         //         msg: message.name + ' successfully joined ' + message.room,
//         //         user: message.name,
//         //         room: message.room,

//         //     });  
//         //     socket.on('new_message', (message) => {
//         //         socket.in(message.room).broadcast.emit('new_join_meesage', {
//         //             msg: message.msg,
//         //             user: message.name,
//         //         }); 
//         //     });
//     });

//        socket.on('new_message', (message) => {
//         socket.in(message.room).broadcast.emit('new_join_meesage', {
//             msg: message.msg,
//             user: message.name,
//         });
//     });

//     socket.on('client_msg', (msg) => {
//         // people.push(socket.id);
//         // people[msg] = socket.id;
//         var room = rooms[socket.id];
//         console.log(room)
//         socket.broadcast.to(room).emit('on_server_msg', msg);
//         // socket.in(username).emit('on_server_msg', msg);
//         console.log(msg);
//         // console.log(people[msg]);
//         // io.emit('on_server_msg' , msg);
//         // console.log(msg)
//     });
//     socket.on('disconnect', () => {
//         numbers--
//         console.log('user disconnected' , numbers);
//     });
// });
app.get('/', (req, res) => {
    res.sendFile(process.cwd() + '/dist/client/index.html')
});
app.use(express.static(process.cwd() + '/dist/client/'));
server.listen(port, () => {
    console.log(`started on port: ${port}`);
});
