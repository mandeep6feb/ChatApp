const express = require('express');
var router = express.Router({mergeParams: true});
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');
let jwt = require('jsonwebtoken');
// const User = mongoose.model('User')
// var { Employee} = require('../models/employee');
let UserRegister = require('../models/userRegisterModel');
const User = require('../models/userRegisterModel')
// module.exports.register = ( res, req, next) => {
//     console.log('testing.....')
// }
router.get('/register/', (req, res) => {
    UserRegister.find( (err, docs) => {
        if(!err)
        {
            res.send(docs);
            let promise = UserRegister.findOne({email: req.body.email}).exec();
            console.log(docs)
        }
        else {
            console.log('Error is Retriving email :' + JSON.stringify( err, undefined, 2));
        }                                                                                                       
    });
});    

router.get('/register/:userId',(req, res) => {
    var userId = req.params.userId;
    UserRegister.findOne( { _id:  userId })
  .then(doc => {
    console.log(doc);
    res.send(doc)
  })
  .catch(err => {
    console.log(err);
  });

//     UserRegister.findById({"_id":{$in: [userId]} }).exec( (err, user) => {
//     if(!err)
//     {
//         res.send('null ' + user);
//         console.log(user);
//     }
//     else {
//         console.log('Error is Retriving email :' );
//     }   
//   });
}); 
// router.post('/', async (request, response) => {
//     try {
//         request.body.password = Bcrypt.hashSync(request.body.password, 10);
//         var user = new UserRegister(request.body);
//         var result = await user.save();
//         response.send(result);
//     } catch (error) {
//         response.status(500).send(error);
//     }
// });
router.patch('/register', (req, res) => {
    var user = new UserRegister({
        name: req.body.name,
        email: req.body.email,
        phone: req.body.phone,
        // password: req.body.password,
        password: bcrypt.hashSync(req.body.password, 10)
    });
    user.save(( err, docs) => {
        if(!err)
        {
            res.send(docs);
            console.log(docs)
        }
    })
});


router.patch('/login', (req, res) => {
    var user = new UserRegister({
        // name: req.body.name,
        // email: req.body.email,
        // phone: req.body.phone,
        // password: bcrypt.hashSync(req.body.password, 10)
    });
   
    let promise = UserRegister.findOne({email: req.body.email}).exec();
    promise.then( (doc) => {
        if(doc) {
            var passwordIsValid = bcrypt.compareSync(req.body.password, doc.password);
            if (!passwordIsValid) return res.status(401).send({ auth: false, token: null });
            // let jwt_secret = 'mysecret';
            // var token = jwt.sign({ id: doc._id }, jwt_secret, {
            //  expiresIn: 86400 // expires in 24 hours
            // });
            // res.status(200).send({ auth: true, token: token });
            res.status(200).send(doc);         
            // console.log(token);
            // console.log(doc.password);
            
        }
        else {
            return res.status(501).json({message: 'User email is not registerd.'})
        }
   
    });
});


  //#endregion


// router.patch('/login', (res, req, next) => {
//     var user = new UserRegister({
//         name: req.body.name,
//         email: req.body.email,
//         phone: req.body.phone,
//         password: bcrypt.hashSync(req.body.password, 10)
//     });
//     let promise = UserRegister.findOne({email: user.email}).exec();

//     promise.then( (doc) => {
//         if(doc) {
//             if(doc.isValid(req.body.password));
//         }
//         else {0
//             return res.status(501).json({message: 'User email is not registerd.'})
//         }
//     });
// })
module.exports = router;